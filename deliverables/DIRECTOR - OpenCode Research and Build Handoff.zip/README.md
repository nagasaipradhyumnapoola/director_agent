# DIRECTOR — research and future build handoff

Prepared **23 November 2026**. Canonical handoff location: **D:\directer agent**. This preparation delivers research and build prompts; application implementation starts only in a later owner-initiated build session.

DIRECTOR is designed as a local-first, persistent supervisor for supported projects across websites/apps, ML/model work, data, research, documents, design and operations. It improves both the main agent and its own work through focused context, selected capabilities, resource limits and independent evidence.

The requested composition is **DIRECTOR core + Headroom + Ponytail + Superpowers + ECC + massive virtual context**. The research explains how those systems work and how to combine selected mechanisms without duplicate controllers, approval loops, memory authorities or unmeasured token overhead.

## OpenCode entry point

Start OpenCode with `opencode "D:\directer agent"`, then ask it to read AGENTS.md and the complete [OpenCode build prompt](OPENCODE_BUILD_PROMPT.md). See [verified host notes and the launch message](docs/OPENCODE_HANDOFF.md). OpenCode 1.19.4 was observed locally; the prompt requires checking actual runtime/schema compatibility. No provider session, plugin install or global reconfiguration was started.

## Start here

1. [Universal product blueprint](docs/DIRECTOR_BLUEPRINT.md) — everything the product should do, domain-specific evidence, architecture, scope and staged roadmap.
2. [Project analysis](docs/PROJECT_ANALYSIS.md) — product thesis, options, ownership, failure risks and cheap validation.
3. [Research synthesis](docs/RESEARCH.md) — dated primary sources, standards, alternatives, 2026 direction and uncertainty.
4. [Master build prompt](docs/MASTER_BUILD_PROMPT.md) — complete standalone prompt for a future build session.
5. [Evaluation plan](docs/EVALUATION_PLAN.md) — concrete acceptance, adversarial cases, three domain pilots and scale benchmarks.
6. [Research status and historical review notes](docs/STATUS.md) — current scope and explicit limits.

## Source-level upstream studies

| Study | Inventory |
|---|---|
| [Headroom implementation analysis](docs/research/HEADROOM_ANALYSIS.md) | [CSV](docs/research/HEADROOM_SKILLS.csv) · [JSON](docs/research/HEADROOM_SKILLS.json) |
| [Ponytail implementation analysis](docs/research/PONYTAIL_ANALYSIS.md) | [CSV](docs/research/PONYTAIL_SKILLS.csv) · [JSON](docs/research/PONYTAIL_SKILLS.json) |
| [Superpowers implementation analysis](docs/research/SUPERPOWERS_ANALYSIS.md) | [CSV](docs/research/SUPERPOWERS_SKILLS.csv) · [JSON](docs/research/SUPERPOWERS_SKILLS.json) |
| [ECC implementation analysis](docs/research/ECC_ANALYSIS.md) | [CSV](docs/research/ECC_SKILLS.csv) · [JSON](docs/research/ECC_SKILLS.json) |

Inventories cover all **1,118 tracked SKILL.md files at the pinned revisions**, with **350 primary/canonical entries** under the reports' definitions. Variants/translations and semantic audit depth are explicitly distinguished. The large ECC JSON is reference evidence for selective lookup, not a file to paste whole into a model context.

No upstream code/hooks/installers/tests were executed. The reports are static source research, not runtime certification. No claim is made that all upstream packages are integrated or every domain works today.

## How to use the handoff

Read the blueprint and analysis, then use the root OpenCode build prompt in an owner-initiated OpenCode session. The generic master prompt remains available for other builders. The future builder must refresh changeable sources, inspect actual workspace state, implement a concrete milestone and produce evidence before claiming success.

This workspace contains only the DIRECTOR research, specification, analysis, inventories, source notices and future build prompt. The interrupted prototype, environment, install scripts and temporary upstream clones were removed from their active locations and sent to the Recycle Bin. Historical review findings remain in STATUS.md as research for the future builder. The curated ZIP contains the same research handoff; no prototype code is included.

Billions of indexed tokens is a future external-memory scale target, not a model attention-window claim. Continuous operation still requires a running host and available resources. Perfect performance on arbitrary work is not promised.
